import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'screens/home_screen.dart';
import 'services/category_store.dart';
import 'services/notification_service.dart';
import 'services/task_store.dart';
import 'theme/app_theme.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
    statusBarColor: Colors.transparent,
    statusBarIconBrightness: Brightness.dark,
    systemNavigationBarColor: Colors.white,
    systemNavigationBarIconBrightness: Brightness.dark,
  ));
  runApp(const TodoApp());
}

class TodoApp extends StatefulWidget {
  const TodoApp({super.key});

  @override
  State<TodoApp> createState() => _TodoAppState();
}

class _TodoAppState extends State<TodoApp> {
  // Dua "gudang data" yang dipakai bersama oleh semua layar.
  final CategoryStore _categories = CategoryStore();
  final TaskStore _store = TaskStore();

  @override
  void initState() {
    super.initState();
    _bootstrap();
  }

  Future<void> _bootstrap() async {
    // Notifikasi & kategori harus siap dulu sebelum tugas dimuat, karena
    // TaskStore langsung menjadwalkan alarm untuk semua tugas saat load().
    await NotificationService.instance.init();
    await _categories.load();
    await _store.load();
  }

  @override
  void dispose() {
    _store.dispose();
    _categories.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'To Do List',
      debugShowCheckedModeBanner: false,
      theme: buildAppTheme(),
      home: HomeScreen(store: _store, categories: _categories),
    );
  }
}
