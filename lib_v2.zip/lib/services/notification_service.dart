import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart' show PlatformException;
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:timezone/data/latest_all.dart' as tz_data;
import 'package:timezone/timezone.dart' as tz;

import '../models/task.dart';

/// Membungkus flutter_local_notifications supaya sisa aplikasi cukup
/// memanggil beberapa method sederhana: init(), scheduleForTask(), dan
/// cancelForTask(). Satu tugas = satu id notifikasi (dari hash id tugas),
/// jadi menjadwalkan ulang otomatis menimpa jadwal lama untuk tugas yang sama.
class NotificationService {
  NotificationService._();
  static final NotificationService instance = NotificationService._();

  final FlutterLocalNotificationsPlugin _plugin =
      FlutterLocalNotificationsPlugin();

  static const _channelId = 'task_deadline_channel';
  static const _channelName = 'Pengingat Deadline Tugas';
  static const _channelDescription =
      'Alarm yang muncul saat deadline tugas sudah dekat atau tiba';

  bool _initialized = false;
  bool _timezoneReady = false;

  Future<void> init() async {
    if (_initialized) return;
    _initialized = true;

    tz_data.initializeTimeZones();
    // Nama zona waktu perangkat tidak selalu tersedia lewat paket ini di semua
    // versi Flutter, jadi dipetakan manual dari offset UTC saat ini
    // (cukup akurat untuk keperluan alarm tugas, tanpa paket tambahan).
    tz.setLocalLocation(_guessLocalLocation());
    _timezoneReady = true;

    const androidInit = AndroidInitializationSettings('@mipmap/ic_launcher');
    const iosInit = DarwinInitializationSettings();
    const settings = InitializationSettings(
      android: androidInit,
      iOS: iosInit,
    );

    await _plugin.initialize(settings: settings);

    final androidImpl = _plugin
        .resolvePlatformSpecificImplementation<
            AndroidFlutterLocalNotificationsPlugin>();

    await androidImpl?.createNotificationChannel(
      const AndroidNotificationChannel(
        _channelId,
        _channelName,
        description: _channelDescription,
        importance: Importance.max,
        playSound: true,
        enableVibration: true,
      ),
    );

    await androidImpl?.requestNotificationsPermission();
    await androidImpl?.requestExactAlarmsPermission();
  }

  /// Perkiraan zona waktu lokal dari selisih UTC saat ini. Cukup untuk alarm
  /// harian; kalau perangkat berpindah zona waktu, jadwalkan ulang tugasnya.
  tz.Location _guessLocalLocation() {
    final offset = DateTime.now().timeZoneOffset;
    final candidates = <Duration, String>{
      const Duration(hours: 7): 'Asia/Jakarta',
      const Duration(hours: 8): 'Asia/Makassar',
      const Duration(hours: 9): 'Asia/Jayapura',
    };
    final name = candidates[offset];
    if (name != null) {
      try {
        return tz.getLocation(name);
      } catch (_) {
        // fall through
      }
    }
    try {
      return tz.getLocation('Etc/GMT${offset.isNegative ? '+' : '-'}'
          '${offset.inHours.abs()}');
    } catch (_) {
      return tz.UTC;
    }
  }

  int _idFor(String taskId) => taskId.hashCode & 0x7fffffff;

  /// Menjadwalkan satu alarm tepat saat deadline tiba, dan (kalau waktunya
  /// masih cukup jauh) satu pengingat 30 menit sebelumnya.
  Future<void> scheduleForTask(Task task) async {
    if (!task.alarmEnabled || task.isDone) {
      await cancelForTask(task.id);
      return;
    }
    if (!_timezoneReady) await init();

    final id = _idFor(task.id);
    await cancelForTask(task.id);

    final due = tz.TZDateTime.from(task.dueDate, tz.local);
    final now = tz.TZDateTime.now(tz.local);

    if (due.isAfter(now)) {
      await _schedule(
        id: id,
        title: '⏰ Waktunya: ${task.title}',
        body: 'Tugas ini sudah mencapai batas waktu sekarang.',
        date: due,
        fullScreen: true,
      );
    }

    final reminder = due.subtract(const Duration(minutes: 30));
    if (reminder.isAfter(now)) {
      await _schedule(
        id: id + 1,
        title: 'Segera deadline: ${task.title}',
        body: 'Sisa 30 menit lagi sampai batas waktu tugas ini.',
        date: reminder,
        fullScreen: false,
      );
    }
  }

  Future<void> _schedule({
    required int id,
    required String title,
    required String body,
    required tz.TZDateTime date,
    required bool fullScreen,
  }) async {
    try {
      await _plugin.zonedSchedule(
        id: id,
        title: title,
        body: body,
        scheduledDate: date,
        androidScheduleMode: AndroidScheduleMode.exactAllowWhileIdle,
        notificationDetails: NotificationDetails(
          android: AndroidNotificationDetails(
            _channelId,
            _channelName,
            channelDescription: _channelDescription,
            importance: Importance.max,
            priority: Priority.high,
            category: AndroidNotificationCategory.alarm,
            fullScreenIntent: fullScreen,
            playSound: true,
            enableVibration: true,
            visibility: NotificationVisibility.public,
          ),
          iOS: const DarwinNotificationDetails(
            presentSound: true,
            interruptionLevel: InterruptionLevel.timeSensitive,
          ),
        ),
      );
    } on PlatformException catch (e) {
      // Izin exact alarm belum diberikan pengguna: alarm dilewati diam-diam
      // supaya aplikasi tidak crash. UI tetap berjalan normal.
      debugPrint('Gagal menjadwalkan notifikasi: $e');
    }
  }

  Future<void> cancelForTask(String taskId) async {
    final id = _idFor(taskId);
    await _plugin.cancel(id: id);
    await _plugin.cancel(id: id + 1);
  }

  bool get supportsExactAlarms => Platform.isAndroid || Platform.isIOS;
}
