import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../services/notification_service.dart';
import '../theme/app_theme.dart';

/// Tab Profil: identitas ringkas pengguna dan pengaturan aplikasi
/// (izin alarm, tentang aplikasi). Belum ada login/akun, karena semua
/// data tersimpan lokal di HP.
class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  static const _nameKey = 'profile_name';
  final _nameController = TextEditingController();
  bool _loaded = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final prefs = await SharedPreferences.getInstance();
    _nameController.text = prefs.getString(_nameKey) ?? 'Pengguna';
    if (mounted) setState(() => _loaded = true);
  }

  Future<void> _saveName(String value) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_nameKey, value);
  }

  @override
  void dispose() {
    _nameController.dispose();
    super.dispose();
  }

  String _initials(String name) {
    final trimmed = name.trim();
    if (trimmed.isEmpty) return '?';
    final parts = trimmed.split(RegExp(r'\s+'));
    final first = parts.first.characters.first;
    final last = parts.length > 1 ? parts.last.characters.first : '';
    return (first + last).toUpperCase();
  }

  @override
  Widget build(BuildContext context) {
    if (!_loaded) return const Center(child: CircularProgressIndicator());

    return ListView(
      padding: const EdgeInsets.fromLTRB(24, 8, 24, 24),
      children: [
        const Text('Profil', style: TextStyle(fontSize: 28, fontWeight: FontWeight.w700)),
        const SizedBox(height: 20),
        Center(
          child: Column(
            children: [
              CircleAvatar(
                radius: 40,
                backgroundColor: AppColors.primaryTint,
                child: Text(
                  _initials(_nameController.text),
                  style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w700, color: AppColors.primary),
                ),
              ),
              const SizedBox(height: 12),
              SizedBox(
                width: 220,
                child: TextField(
                  controller: _nameController,
                  textAlign: TextAlign.center,
                  style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w600),
                  decoration: const InputDecoration(border: InputBorder.none, isDense: true),
                  onChanged: (value) {
                    _saveName(value);
                    setState(() {});
                  },
                ),
              ),
              const Text('Data tersimpan di HP ini saja', style: TextStyle(fontSize: 13, color: AppColors.textSecondary)),
            ],
          ),
        ),
        const SizedBox(height: 28),
        const Text('Pengaturan', style: TextStyle(fontSize: 15, fontWeight: FontWeight.w600)),
        const SizedBox(height: 12),
        Container(
          decoration: AppDecorations.card(),
          child: Column(
            children: [
              ListTile(
                leading: const Icon(Icons.alarm_rounded, color: AppColors.primary),
                title: const Text('Izin alarm & notifikasi'),
                subtitle: const Text('Wajib aktif agar pengingat deadline berbunyi'),
                trailing: const Icon(Icons.chevron_right_rounded),
                onTap: () async {
                  final impl = NotificationService.instance;
                  await impl.init();
                  if (context.mounted) {
                    ScaffoldMessenger.of(context)
                      ..hideCurrentSnackBar()
                      ..showSnackBar(const SnackBar(
                        content: Text('Izin alarm diminta ulang. Cek pengaturan HP kalau belum muncul.'),
                      ));
                  }
                },
              ),
              const Divider(height: 1, color: AppColors.borderLight),
              const ListTile(
                leading: Icon(Icons.info_outline_rounded, color: AppColors.textSecondary),
                title: Text('Tentang aplikasi'),
                subtitle: Text('To Do List · versi 1.0.0'),
              ),
            ],
          ),
        ),
      ],
    );
  }
}
