package com.example.to_do_list

import android.content.Intent
import androidx.core.content.FileProvider
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel
import java.io.File

class MainActivity : FlutterActivity() {
    private val CHANNEL = "todolist/file_provider"

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)

        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, CHANNEL).setMethodCallHandler { call, result ->
            if (call.method == "getContentUri") {
                val path = call.argument<String>("path")
                if (path == null) {
                    result.error("NO_PATH", "Path tidak diberikan", null)
                    return@setMethodCallHandler
                }
                try {
                    val file = File(path)
                    val authority = "$packageName.fileprovider"
                    val uri = FileProvider.getUriForFile(applicationContext, authority, file)
                    try {
                        // Memberi izin baca ke komponen sistem yang memutar suara notifikasi.
                        grantUriPermission("com.android.systemui", uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    } catch (_: Exception) {
                        // Diamkan: sebagian perangkat menolak grant eksplisit ini,
                        // tapi suara notifikasi biasanya tetap berfungsi.
                    }
                    result.success(uri.toString())
                } catch (e: Exception) {
                    result.error("FILE_PROVIDER_ERROR", e.message, null)
                }
            } else {
                result.notImplemented()
            }
        }
    }
}
