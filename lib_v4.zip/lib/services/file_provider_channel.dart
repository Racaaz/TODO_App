import 'package:flutter/services.dart';

/// Jembatan ke kode native Android (lihat MainActivity.kt) untuk mengubah
/// path file lokal aplikasi menjadi content:// URI yang bisa dibaca sistem.
/// Ini dibutuhkan karena Android tidak mengizinkan proses sistem (yang
/// memutar suara notifikasi) membaca langsung file di folder privat
/// aplikasi lewat path biasa.
class FileProviderChannel {
  FileProviderChannel._();
  static const _channel = MethodChannel('todolist/file_provider');

  static Future<String?> contentUriFor(String path) async {
    try {
      return await _channel.invokeMethod<String>('getContentUri', {'path': path});
    } on PlatformException {
      return null;
    } on MissingPluginException {
      return null;
    }
  }

  /// Membuka layar sistem untuk mengecualikan aplikasi dari pembatasan
  /// baterai, supaya alarm tetap bisa bunyi saat HP terkunci/tidur lama.
  /// Mengembalikan true kalau layarnya berhasil dibuka.
  static Future<bool> requestIgnoreBatteryOptimizations() async {
    try {
      final opened = await _channel.invokeMethod<bool>('requestIgnoreBatteryOptimizations');
      return opened ?? false;
    } on PlatformException {
      return false;
    } on MissingPluginException {
      return false;
    }
  }
}
