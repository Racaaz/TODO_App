import 'package:flutter/services.dart';

/// Jembatan ke kode native Android (lihat MainActivity.kt).
class FileProviderChannel {
  FileProviderChannel._();
  static const _channel = MethodChannel('todolist/file_provider');

  /// Mendaftarkan file suara custom ke MediaStore Android, mengembalikan
  /// content:// URI yang bisa langsung dipakai untuk suara notification
  /// channel. Lebih andal daripada FileProvider biasa, terutama di HP
  /// dengan Android custom seperti MIUI/HyperOS.
  static Future<String?> registerNotificationSound(String path) async {
    try {
      return await _channel.invokeMethod<String>('registerNotificationSound', {'path': path});
    } on PlatformException {
      return null;
    } on MissingPluginException {
      return null;
    }
  }

  /// Membuka layar sistem untuk mengecualikan aplikasi dari pembatasan
  /// baterai, supaya alarm tetap bisa bunyi saat HP terkunci/tidur lama.
  static Future<bool> requestIgnoreBatteryOptimizations() async {
    try {
      final opened = await _channel.invokeMethod<bool>('requestIgnoreBatteryOptimizations');
      return opened ?? false;
    } on PlatformException {
      return false;
    } on MissingPluginException {
      return false;
    }
  }
}
